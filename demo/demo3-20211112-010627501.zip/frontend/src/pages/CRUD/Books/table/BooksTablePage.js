import React from 'react';
import BooksTable from 'pages/CRUD/Books/table/BooksTable';

const BooksTablePage = () => {
  return (
    <div>
      <BooksTable />
    </div>
  );
}

export default BooksTablePage;
