import React from 'react';
import Table_5Table from 'pages/CRUD/Table_5/table/Table_5Table';

const Table_5TablePage = () => {
  return (
    <div>
      <Table_5Table />
    </div>
  );
}

export default Table_5TablePage;
