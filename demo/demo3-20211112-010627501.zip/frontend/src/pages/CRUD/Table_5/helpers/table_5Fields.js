

const table_5Fields = {
	id: { type: 'id', label: 'ID' },
newColumn: { type: 'int', label: 'newTitle',

    },

}

export default table_5Fields;
