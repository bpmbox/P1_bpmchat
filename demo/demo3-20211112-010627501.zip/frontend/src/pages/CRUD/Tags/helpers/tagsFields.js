

const tagsFields = {
	id: { type: 'id', label: 'ID' },
name: { type: 'string', label: 'Name',

    },

}

export default tagsFields;
