

const table_4Fields = {
	id: { type: 'id', label: 'ID' },
newColumn: { type: 'string', label: 'newTitle',

    },
tettt: { type: 'string', label: 'tettt',

    },

}

export default table_4Fields;
