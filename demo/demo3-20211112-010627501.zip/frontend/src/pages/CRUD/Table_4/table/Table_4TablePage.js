import React from 'react';
import Table_4Table from 'pages/CRUD/Table_4/table/Table_4Table';

const Table_4TablePage = () => {
  return (
    <div>
      <Table_4Table />
    </div>
  );
}

export default Table_4TablePage;
