<?php

namespace App\Repositories;

use Illuminate\Support\Collection;

interface Table_5RepositoryInterface extends EloquentRepositoryInterface
{

}

    
