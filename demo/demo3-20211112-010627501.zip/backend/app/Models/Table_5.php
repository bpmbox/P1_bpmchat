<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Table_5 extends Model {
    protected static $unguarded = true;

}
    
