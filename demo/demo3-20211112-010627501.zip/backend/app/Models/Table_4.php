<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Table_4 extends Model {
    protected static $unguarded = true;

}
    
