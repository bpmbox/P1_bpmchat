<?php

use Illuminate\Support\Facades\Artisan;

Artisan::command('test', function () {
    dd();
});
